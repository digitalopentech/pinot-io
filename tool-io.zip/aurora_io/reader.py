from pathlib import Path
from typing import List
from typing import Union

from .data_format import ReadingFormat
from .resource_managers import ResourceManager, ResourceType


class Reader(object):

    def __init__(self, resource_manager: ResourceManager):
        self.__resource_manager = resource_manager

    def load(self, path: Union[Path, List[Path]], reading_format: ReadingFormat, columns: List[str] = None):
        files_data = []
        column_names = columns

        paths = path
        if type(paths) is not list:
            paths = [path]

        for unique_path in paths:
            for file_path in self.__resource_manager.list(unique_path, include=[ResourceType.FILE]):
                with self.__resource_manager.open_for_reading(path=file_path.path) as file:
                    file_data = reading_format.read(file, columns=column_names)

                    if file_data is None:
                        print(F"Error Reading {file_path.path}. See error above")
                        continue

                    if column_names is None:
                        column_names = list(file_data.columns)
                    elif set(column_names) != set(file_data.columns):
                        raise AssertionError(F"Incompatible DataFrames: {column_names} vs. {set(file_data.columns)}")

                    files_data.append(file_data[column_names])

        return reading_format.concat(files_data)
