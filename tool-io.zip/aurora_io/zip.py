import zipfile
from pathlib import Path
from typing import NoReturn, Union


def extract_zip(zip_file: Union[str, Path], output: Path) -> NoReturn:
    with zipfile.ZipFile(zip_file, "r") as zip_ref:
        zip_ref.extractall(str(output))
