from pathlib import Path
from typing import List, NoReturn

from aurora_io.aws import AWSS3, BufferType
from aurora_io.resource_managers import ResourceManager, ResourceType, Resource


class Ozone(ResourceManager):
    def __init__(self,
                 default_bucket: str = 'hdfs',
                 endpoint_url: str = 'http://spobrdatalab04n.br.experian.local:9878',
                 buffer_type: BufferType = BufferType.MEMORY,
                 **read_options):
        self.__default_path = Path("/")
        if default_bucket is not None:
            self.__default_path = self.__default_path.joinpath(default_bucket)

        self.__s3 = AWSS3(buffer_type=buffer_type,
                          endpoint_url=endpoint_url,
                          aws_access_key_id="ozone_user",
                          aws_secret_access_key="ozone_pass",
                          **read_options)

    def list(self, path: Path, include: List[ResourceType] = None) -> List[Resource]:
        return [Resource(path=self.__relative_to_default_bucket(resource.path),
                         type=resource.type)
                for resource in self.__s3.list(path=self.__put_bucket_path(path), include=include)]

    def exists(self, path: Path) -> bool:
        return self.__s3.exists(path=self.__put_bucket_path(path))

    def open(self, path: Path, mode: str, allow_override: bool = False):
        return self.__s3.open(path=self.__put_bucket_path(path),
                              mode=mode,
                              allow_override=allow_override)

    def get_json_object(self, path: Path):
        return self.__s3.get_json_object(path=self.__put_bucket_path(path))

    def upload_object_file(self, path: Path, destination: Path):
        self.__s3.upload_object_file(path=path, destination=self.__put_bucket_path(destination))

    def download_object(self, path: Path, destination: Path):
        self.__s3.download_object(path=self.__put_bucket_path(path), destination=destination)

    def rm(self, path: Path, recursive: bool = False) -> NoReturn:
        self.__s3.rm(path=self.__put_bucket_path(path), recursive=recursive)

    def mkdir(self, path: Path, recursive: bool = False) -> NoReturn:
        pass

    def __put_bucket_path(self, path: Path):
        path = str(path)
        prefix = "/"
        if path.startswith(prefix):
            path = path[len(prefix):]
        return self.__default_path.joinpath(path)

    def __relative_to_default_bucket(self, path: Path):
        return Path("/").joinpath(path.relative_to(self.__default_path))
