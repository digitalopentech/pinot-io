import json
import tempfile
import uuid
from enum import Enum, auto, unique
from pathlib import Path
from typing import List, NoReturn
from urllib.parse import urlparse

import boto3
from s3fs import S3FileSystem

from aurora_io.resource_managers import ResourceManager, ResourceType, Resource


@unique
class BufferType(Enum):
    FILE = auto()
    MEMORY = auto()


class S3Url(object):

    def __init__(self, url):
        self._parsed = urlparse(url, allow_fragments=False)

    @staticmethod
    def from_path(path: Path):
        bucket_part = path.parents[len(path.parents) - 2]
        bucket_name = bucket_part.name
        key = str(path.relative_to(bucket_part))

        return S3Url(F"s3://{bucket_name}/{key}")

    @property
    def bucket(self):
        return self._parsed.netloc

    @property
    def key(self):
        if self._parsed.query:
            return self._parsed.path.lstrip('/') + '?' + self._parsed.query
        else:
            return self._parsed.path.lstrip('/')

    @property
    def url(self):
        return self._parsed.geturl()

    @property
    def path(self):
        return Path(F"/{self.bucket}/{self.key}")


class AWSS3(ResourceManager):
    __default_read_options = {
        "Delimiter": "/"
    }

    def __init__(self, buffer_type: BufferType = BufferType.MEMORY,
                 endpoint_url: str = None,
                 aws_access_key_id: str = None,
                 aws_secret_access_key: str = None,
                 **read_options):
        self.__buffer_type = buffer_type
        if read_options is None:
            read_options = {}
        self.__read_options = {**self.__default_read_options, **read_options}

        self.__s3 = boto3.client('s3',
                                 endpoint_url=endpoint_url,
                                 aws_access_key_id=aws_access_key_id,
                                 aws_secret_access_key=aws_secret_access_key)
        self.__s3fs = S3FileSystem(anon=False,
                                   client_kwargs=dict(endpoint_url=endpoint_url,
                                                      aws_access_key_id=aws_access_key_id,
                                                      aws_secret_access_key=aws_secret_access_key))
        self.__list_paginator = self.__s3.get_paginator('list_objects_v2')

    def list(self, path: Path, include: List[ResourceType] = None) -> List[Resource]:
        if (include is None) or (len(include) == 0):
            include = set(ResourceType)
        else:
            include = set(include)

        s3_url = S3Url.from_path(path=path)

        return self.list_bucket(bucket=s3_url.bucket,
                                key=s3_url.key,
                                include=list(include))

    def exists(self, path: Path) -> bool:
        resources = self.list(path=path)

        for resource in resources:
            if (resource.path == path) or (str(resource.path).startswith(f"{str(path)}/")):
                return True

        return False

    def list_bucket(self, bucket: str, key: str, include: List[ResourceType] = None) -> List[Resource]:
        if (include is None) or (len(include) == 0):
            include = set(ResourceType)
        else:
            include = set(include)

        paths_iterator = self.__list_paginator.paginate(
            Bucket=bucket,
            Prefix=key,
            **self.__read_options
        )

        base_path = Path(F"/{bucket}")
        resources = []
        for path_page in paths_iterator:
            resources.extend([Resource(path=base_path.joinpath(file["Key"]), type=ResourceType.FILE)
                              for file in path_page.get("Contents", [])
                              if not file["Key"].endswith("/")])
            resources.extend([Resource(path=base_path.joinpath(file["Prefix"]), type=ResourceType.DIRECTORY)
                              for file in path_page.get("CommonPrefixes", [])])

        if self.__exist_identical_directory(resources, base_path.joinpath(key)):
            resources = self.list_bucket(bucket=bucket, key=F"{key}/")

        return [resource for resource in resources if resource.type in include]

    @staticmethod
    def __exist_identical_directory(resources: List[Resource], path: Path):
        for resource in resources:
            if (resource.type == ResourceType.DIRECTORY) and (resource.path == path):
                return True

        return False

    def open(self, path: Path, mode: str, allow_override: bool = False):
        if mode not in ["r", "rb", "w", "wb"]:
            raise AssertionError(F"Mode not Supported: {mode}")

        if ('w' in mode) and (not allow_override) and self.__s3fs.exists(path=str(path)):
            raise AssertionError(F"Override is not allowed! Dir: {str(path)}")

        if (self.__buffer_type == BufferType.MEMORY) or (mode.find("w") >= 0):
            return self.__s3fs.open(path=str(path.relative_to("/")), mode=mode)

        temporary_file = Path(tempfile.gettempdir()).joinpath(str(uuid.uuid4()))

        self.download_object(path=path,
                             destination=temporary_file)

        return open(str(temporary_file), mode=mode)

    def get_json_object_s3(self, s3_url: S3Url):
        return self.get_json_object(path=s3_url.path)

    def get_json_object(self, path: Path):
        with self.open(path=path, mode="r") as jf:
            return json.load(jf)

    def upload_object_file(self, path: Path, destination: Path):
        s3_url = S3Url.from_path(path=destination)

        self.upload_object_file_s3(path=path, destination=s3_url)

    def upload_object_file_s3(self, path: Path, destination: S3Url):
        self.__s3.upload_file(Bucket=destination.bucket,
                              Key=destination.key,
                              Filename=str(path))

    def download_object(self, path: Path, destination: Path):
        s3_url = S3Url.from_path(path=path)

        self.download_object_s3(source=s3_url, destination=destination)

    def download_object_s3(self, source: S3Url, destination: Path):
        self.__s3.download_file(Bucket=source.bucket,
                                Key=source.key,
                                Filename=str(destination))

    def rm(self, path: Path, recursive: bool = False) -> NoReturn:
        real_path = str(path.relative_to("/"))
        if recursive:
            self.__s3fs.rmdir(real_path)
        else:
            self.__s3fs.rm(real_path)

    def mkdir(self, path: Path, recursive: bool = False) -> NoReturn:
        pass
