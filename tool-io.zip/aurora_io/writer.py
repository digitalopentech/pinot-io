from pathlib import Path

from .data_format import WritingFormat
from .resource_managers import ResourceManager


class Writer(object):

    def __init__(self, resource_manager: ResourceManager):
        self.__resource_manager = resource_manager

    def write(self, path: Path, data, writing_format: WritingFormat, allow_override: bool = False):
        with self.__resource_manager.open_for_writing(path, allow_override=allow_override) as file:
            writing_format.save(file, data)
