from pathlib import Path
import os
import logging
from aurora_io.aws import AWSS3
from aurora_io.ozone import Ozone
from aurora_io.resource_managers import Resource, ResourceType

os.environ['AWS_ACCESS_KEY_ID'] = "AKIAYPSTBR4MLZIYRXW2"
os.environ['AWS_SECRET_ACCESS_KEY'] = "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"

# Crie uma instância de AWSS3
s3_client = AWSS3(
    aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'],
    aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY']
)

# Crie uma instância de Ozone
ozone_client = Ozone()

# Caminhos dos arquivos
input_file = Path("/serasaexperian-agro-datalake-transient-uat/data/facon-pj/")
output_file = Path("/projetos/esg/data/clients/pocs/cecafe/cecafe_alfredo/")

# Chame o método copy na instância de AWSS3

s3_client.recursive_copy(source=input_file, target=output_file, destination_resource_manager=ozone_client)

files = ozone_client.list(path=Path("/projetos/esg/data/clients/pocs/cecafe/cecafe_alfredo/"), include=[ResourceType.FILE])

print(files)

for file in files:
    logging.info(f"File in Ozone: {file.path}")
