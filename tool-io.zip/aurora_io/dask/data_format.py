import logging
from abc import ABC
from typing import List, Union

from dask import dataframe as dd

from aurora_io.dask.resource_managers import Path
from aurora_io.data_format import ReadingFormat
from aurora_io.pandas.data_format import PandasReadingFormat


class DaskReadingFormat(ReadingFormat, ABC):
    def concat(self, dataframes: List[dd.DataFrame]) -> dd.DataFrame:
        return dd.concat(dataframes, axis=0)


class ParquetFormat(DaskReadingFormat):
    def __init__(self, engine: str = "auto",
                 read_options: dict = None):
        if read_options is None:
            read_options = {}

        self.__engine = engine
        self.__read_options = {**read_options, "engine": self.__engine}

    def read(self, file: Path, columns: List[str] = None) -> Union[dd.DataFrame, None]:
        try:
            return dd.read_parquet(file, columns=columns, **self.__read_options)
        except Exception as e:
            logging.warning(F"Error Reading data: {e}")
            return None


class CSVFormat(PandasReadingFormat):
    __default_read_options = {
        "sep": ",",
    }

    def __init__(self, read_options: dict = None):
        if read_options is None:
            read_options = self.__default_read_options

        self.__read_options = read_options

    def read(self, file: Path, columns: List[str] = None) -> Union[dd.DataFrame, None]:
        try:
            if columns is None:
                columns = []

            df = dd.read_csv(file, **self.__read_options)

            if df is None:
                return None

            if len(columns) > 0:
                df = df.loc[:, columns]

            return df
        except Exception as e:
            logging.warning(F"Error Reading data: {e}")
            return None
