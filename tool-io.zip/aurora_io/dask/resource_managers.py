from dataclasses import dataclass
from pathlib import Path

from aurora_io.resource_managers import HDFSClient, LocalFileSystem


@dataclass
class Path(object):
    name: str
    path: str

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass


class LocalFileSystemForDask(LocalFileSystem):

    def open(self, path: Path, mode: str, allow_override: bool = False) -> Path:
        return Path(name=str(path), path=f"file://{path}")


class HDFSClientForDask(HDFSClient):
    def __init__(self, host: str = "spobrdatalab10", user: str = "hdfs", port: int = 8020):
        super().__init__(host=host,
                         user=user,
                         port=port)

    def open(self, path: Path, mode: str, allow_override: bool = False) -> Path:
        return Path(name=str(path), path=f"hdfs://{path}")
