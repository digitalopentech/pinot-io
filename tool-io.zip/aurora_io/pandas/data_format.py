import logging
from abc import ABC, abstractmethod
from typing import Union, NoReturn, List

import pandas as pd

from aurora_io.data_format import ReadingFormat, WritingFormat


class PandasWritingFormat(WritingFormat, ABC):
    @abstractmethod
    def save(self, file, data: pd.DataFrame) -> NoReturn:
        pass


class PandasReadingFormat(ReadingFormat, ABC):

    @abstractmethod
    def read(self, file, columns: List[str] = None) -> pd.DataFrame:
        pass

    def concat(self, dataframes: List[pd.DataFrame]) -> pd.DataFrame:
        return pd.concat(dataframes, axis=0)


class ExcelFormat(PandasReadingFormat):
    def __init__(self, read_options: dict = None):
        if read_options is None:
            read_options = {}

        self.__read_options = read_options

    def read(self, file, columns: List[str] = None) -> Union[pd.DataFrame, None]:
        if columns is None:
            columns = []
        df = pd.read_excel(file, **self.__read_options)

        if df is None:
            return None

        if len(columns) > 0:
            df = df.loc[:, columns]

        return df


class SASFormat(PandasReadingFormat):
    def __init__(self, engine: str = "auto",
                 read_options: dict = None):
        self.__engine = engine
        if read_options is None:
            read_options = {}

        self.__read_options = read_options

    def read(self, file, columns: List[str] = None) -> Union[pd.DataFrame, None]:
        if columns is None:
            columns = []

        df = None
        if self.__engine == "auto":
            try:
                df = self.__sas7bdat_read(file, **self.__read_options)
            except:
                df = self.__pandas_read(file, **self.__read_options)
        elif self.__engine == "pandas":
            df = self.__pandas_read(file, **self.__read_options)
        elif self.__engine == "sas7bdat":
            df = self.__sas7bdat_read(file, **self.__read_options)

        if df is None:
            return None

        if len(columns) > 0:
            df = df.loc[:, columns]

        return df

    @staticmethod
    def __pandas_read(file, **kwargs) -> Union[pd.DataFrame, None]:
        return pd.read_sas(file, **kwargs)

    @staticmethod
    def __sas7bdat_read(file, **kwargs) -> pd.DataFrame:
        from sas7bdat import SAS7BDAT
        with SAS7BDAT(path="/fake", fh=file, **kwargs) as reader:
            return reader.to_data_frame()


class ParquetFormat(PandasWritingFormat, PandasReadingFormat):
    __default_write_options = {
        "preserve_index": False,
    }

    def __init__(self, engine: str = "auto",
                 read_options: dict = None,
                 write_options: dict = None):
        if read_options is None:
            read_options = {}

        if write_options is None:
            write_options = self.__default_write_options

        self.__engine = engine
        self.__read_options = {**read_options, "engine": self.__engine}
        self.__write_options = write_options

    def read(self, file, columns: List[str] = None) -> Union[pd.DataFrame, None]:
        try:
            return pd.read_parquet(file, columns=columns, **self.__read_options)
        except Exception as e:
            logging.warning(F"Error Reading data: {e}")
            return None

    def save(self, file, data: pd.DataFrame) -> NoReturn:
        if self.__engine in ["pyarrow", "auto"]:
            import pyarrow
            from pyarrow import parquet

            parquet.write_table(
                pyarrow.Table.from_pandas(data, **self.__write_options),
                file,
            )
        else:
            raise AssertionError("Only pyarrow engine is available for writing")


class CSVFormat(PandasWritingFormat, PandasReadingFormat):
    __default_read_options = {
        "sep": ",",
    }

    __default_write_options = {
        "sep": ",",
        "index": False,
    }

    def __init__(self, read_options: dict = None,
                 write_options: dict = None):
        if read_options is None:
            read_options = self.__default_read_options

        if write_options is None:
            write_options = self.__default_write_options

        self.__read_options = read_options
        self.__write_options = write_options

    def read(self, file, columns: List[str] = None) -> Union[pd.DataFrame, None]:
        try:
            if columns is None:
                columns = []

            df = pd.read_csv(file, **self.__read_options)

            if df is None:
                return None

            if len(columns) > 0:
                df = df.loc[:, columns]

            return df
        except Exception as e:
            logging.warning(F"Error Reading data: {e}")
            return None

    def save(self, file, data: pd.DataFrame) -> NoReturn:
        data.to_csv(file, **self.__write_options)
