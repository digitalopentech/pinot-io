from abc import ABC, abstractmethod
from typing import NoReturn, List


class WritingFormat(ABC):

    @abstractmethod
    def save(self, file, data) -> NoReturn:
        pass


class ReadingFormat(ABC):

    @abstractmethod
    def read(self, file, columns: List[str] = None):
        pass

    @abstractmethod
    def concat(self, dataframes):
        pass
