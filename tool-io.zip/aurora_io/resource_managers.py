import shutil
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum, unique, auto
from io import open
from os import listdir, rmdir, remove
from os.path import isfile, isdir, exists
from pathlib import Path
from typing import List, NoReturn

from pyarrow import HdfsFile, hdfs
from typing_extensions import Self


@unique
class ResourceType(Enum):
    FILE = auto()
    DIRECTORY = auto()


@dataclass(frozen=True)
class Resource(object):
    path: Path
    type: ResourceType


class ResourceManager(ABC):

    def open_for_reading(self, path: Path):
        return self.open(path=path, mode="rb")

    def open_for_writing(self, path: Path, allow_override: bool = False):
        return self.open(path=path, mode="wb", allow_override=allow_override)

    @abstractmethod
    def open(self, path: Path, mode: str, allow_override: bool = False):
        pass

    @abstractmethod
    def list(self, path: Path, include: List[ResourceType] = None) -> List[Resource]:
        pass

    @abstractmethod
    def exists(self, path: Path) -> bool:
        pass

    def copy(self, input_file: Path, output_file: Path, destination_resource_manager: Self = None, allow_override: bool = False) -> NoReturn:
        if destination_resource_manager is None:
            destination_resource_manager = self

        print("Entro no metodo copy")

        if not self.exists(path=input_file):
            print("primeiro if")
            raise AssertionError(F"The input file does not exist: {input_file}")

        if len(self.list(path=input_file, include=[ResourceType.FILE])) == 0:
            print("segundo if")
            raise AssertionError(F"The input file is not a regular file: {input_file}")


        with self.open_for_reading(path=input_file) as f_input:
            with destination_resource_manager.open_for_writing(path=output_file, allow_override=allow_override) as f_output:
                shutil.copyfileobj(f_input, f_output)

    def recursive_copy(self, source: Path, target: Path, destination_resource_manager: Self = None, allow_override: bool = False) -> NoReturn:
        if destination_resource_manager is None:
            destination_resource_manager = self

        resources_to_copy = self.list(path=source)
        while len(resources_to_copy) > 0:
            resource = resources_to_copy.pop()
            path = resource.path
            if resource.type == ResourceType.FILE:
                if path == source:
                    target_path = target
                else:
                    target_path = target.joinpath(self.__remove_prefix(str(path), F"{source}/"))
                destination_resource_manager.mkdir(target_path.parent)
                self.copy(input_file=path, output_file=target_path,
                          destination_resource_manager=destination_resource_manager,
                          allow_override=allow_override)
            elif resource.type == ResourceType.DIRECTORY:
                target_path = target.joinpath(self.__remove_prefix(str(path), F"{source}/"))
                destination_resource_manager.mkdir(path=target_path, recursive=True)
                self.recursive_copy(source=path, target=target_path,
                                    destination_resource_manager=destination_resource_manager,
                                    allow_override=allow_override)
            else:
                raise AssertionError(f"Unknown type: {resource.type}")

    def copy_from_local(self, from_local_path: Path, to_path: Path, allow_override: bool = False) -> NoReturn:
        LocalFileSystem().recursive_copy(source=from_local_path,
                                         target=to_path,
                                         destination_resource_manager=self,
                                         allow_override=allow_override)

    def copy_to_local(self, from_path: Path, to_local_path: Path, allow_override: bool = False) -> NoReturn:
        self.recursive_copy(source=from_path,
                            target=to_local_path,
                            destination_resource_manager=LocalFileSystem(),
                            allow_override=allow_override)

    @staticmethod
    def __remove_prefix(string, prefix):
        if string.startswith(prefix):
            return string[len(prefix):]
        else:
            return string

    @abstractmethod
    def rm(self, path: Path, recursive: bool = False) -> NoReturn:
        pass

    @abstractmethod
    def mkdir(self, path: Path, recursive: bool = False) -> NoReturn:
        pass


class HDFSClient(ResourceManager):

    def __init__(self, host: str = "spobrdatalab02n.br.experian.local", user: str = "hdfs", port: int = 8020):
        self.__host = host
        self.__user = user
        self.__port = port
        self.__connection = None

    def __check_connection(self):
        if self.__connection is None:
            self.__connection = hdfs.connect(host=self.__host, port=self.__port, user=self.__user)

        return self.__connection

    def list(self, path: Path, include: List[ResourceType] = None) -> List[Resource]:
        if (include is None) or (len(include) == 0):
            include = set(ResourceType)
        else:
            include = set(include)

        self.__check_connection()
        if self.__connection.isfile(path=str(path)):
            return [Resource(path=path,
                             type=ResourceType.FILE)] if ResourceType.FILE in include else []

        return [resource
                for resource in [Resource(path=Path(file_metadata["name"]),
                                          type=ResourceType.FILE if file_metadata["kind"] == "file" else ResourceType.DIRECTORY)
                                 for file_metadata in self.__connection.ls(path=str(path), detail=True)]
                if resource.type in include]

    def exists(self, path: Path) -> bool:
        self.__check_connection()

        return self.__connection.exists(str(path))

    def open(self, path: Path, mode: str, allow_override: bool = False) -> HdfsFile:
        self.__check_connection()

        if ('w' in mode) and (not allow_override) and self.__connection.exists(path=str(path)):
            raise AssertionError(F"Override is not allowed! Dir: {str(path)}")

        return self.__connection.open(path=str(path), mode=mode)

    def copy_from_local(self, from_local_path: Path, to_path: Path, allow_override: bool = False) -> NoReturn:
        self.__check_connection()

        if isfile(str(from_local_path)):
            with open(str(from_local_path), mode="rb") as single_file:
                if self.__connection.exists(path=str(to_path)) and (not allow_override):
                    raise AssertionError(F"Override is not allowed! Dir: {str(to_path)}")
                self.__connection.upload(path=str(to_path), stream=single_file)
        elif isdir(str(from_local_path)):
            for current_path in listdir(str(from_local_path)):
                self.copy_from_local(from_local_path=from_local_path.joinpath(current_path),
                                     to_path=to_path.joinpath(current_path))

    @staticmethod
    def __remove_prefix(string, prefix):
        if string.startswith(prefix):
            return string[len(prefix):]
        else:
            return string

    def copy_to_local(self, from_path: Path, to_local_path: Path, allow_override: bool = False) -> NoReturn:
        self.__check_connection()

        if not to_local_path.exists():
            raise AssertionError(F"Destination Folder [{to_local_path}] does not exists")

        for resource in self.list(path=from_path):
            path = resource.path

            if resource.type is ResourceType.FILE:
                with self.open_for_reading(path=path) as hdfs_file:
                    if path == from_path:
                        local_path = to_local_path.joinpath(from_path.name)
                    else:
                        local_path = to_local_path.joinpath(self.__remove_prefix(str(path), F"{from_path}/"))
                        local_path.parent.mkdir(exist_ok=True)

                    with local_path.open(mode="wb") as local_file:
                        shutil.copyfileobj(hdfs_file, local_file)
            elif resource.type is ResourceType.DIRECTORY:
                local_path = to_local_path.joinpath(self.__remove_prefix(str(path), F"{from_path}/"))
                local_path.mkdir(exist_ok=False)
                self.copy_to_local(from_path=path, to_local_path=local_path)

    def rm(self, path: Path, recursive: bool = False) -> NoReturn:
        self.__check_connection()

        self.__connection.delete(path=str(path), recursive=recursive)

    def mkdir(self, path: Path, recursive: bool = False) -> NoReturn:
        self.__check_connection()

        self.__connection.mkdir(path=str(path))


class LocalFileSystem(ResourceManager):

    def list(self, path: Path, include: List[ResourceType] = None) -> List[Resource]:
        if (include is None) or (len(include) == 0):
            include = set(ResourceType)
        else:
            include = set(include)

        if isfile(path):
            return [Resource(path=path,
                             type=ResourceType.FILE)] if ResourceType.FILE in include else []

        return [resource
                for resource in [Resource(path=path.joinpath(inner_file),
                                          type=ResourceType.FILE if isfile(str(path.joinpath(inner_file))) else ResourceType.DIRECTORY)
                                 for inner_file in listdir(path)]
                if resource.type in include]

    def exists(self, path: Path) -> bool:
        return exists(str(path))

    def open(self, path: Path, mode: str, allow_override: bool = False):
        if ('w' in mode) and (not allow_override) and exists(path=str(path)):
            raise AssertionError(F"Override is not allowed! Dir: {str(path)}")

        return open(str(path), mode=mode)

    def rm(self, path: Path, recursive: bool = False) -> NoReturn:
        if recursive:
            rmdir(str(path))
        else:
            remove(str(path))

    def mkdir(self, path: Path, recursive: bool = False) -> NoReturn:
        path.mkdir(parents=recursive, exist_ok=True)
